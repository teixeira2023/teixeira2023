# Friedrich Method Applied to Software Test Optimization

## Reducing Complexity: From Rubik's Cube to Test Cases

---

## Table of Contents

1. [Introduction](#1-introduction)
2. [The Friedrich Method (CFOP)](#2-the-friedrich-method-cfop)
3. [The Analogy: Cube × Software](#3-the-analogy-cube--software)
4. [Test Case Reduction Techniques](#4-test-case-reduction-techniques)
5. [Practical Application with Examples](#5-practical-application-with-examples)
6. [Tools and Implementation](#6-tools-and-implementation)
7. [Templates and Checklists](#7-templates-and-checklists)
8. [Conclusion](#8-conclusion)

---

## 1. Introduction

### 1.1 The Problem of Combinatorial Complexity

In any non-trivial software system, the number of possible combinations of inputs, states, and scenarios grows exponentially. Testing all combinations is:

- **Financially unfeasible**
- **Temporally impossible**
- **Practically unnecessary**

> **Pareto Principle in Testing**: 80% of bugs are found with 20% of well-chosen tests.

### 1.2 The Solution: Strategic Thinking

Just as Jessica Fridrich developed a method to solve the Rubik's cube efficiently, we can apply the same principles to optimize our software testing.

---

## 2. The Friedrich Method (CFOP)

### 2.1 History and Context

| Aspect | Detail |
|--------|--------|
| **Creator** | Jessica Fridrich (Czech Engineer) |
| **Year** | Developed after the 1982 World Championship |
| **Average Time** | ~17 seconds (professional speedcubers) |
| **Total Algorithms** | ~119 (41 F2L + 57 OLL + 21 PLL) |

### 2.2 The Four Steps of CFOP

```
┌─────────────────────────────────────────────────────────────┐
│                    FRIEDRICH METHOD                         │
├─────────────────────────────────────────────────────────────┤
│  C → Cross                 │  Build white cross on base     │
│  F → F2L                   │  First two layers              │
│  O → OLL                   │  Orient last layer             │
│  P → PLL                   │  Permute last layer            │
└─────────────────────────────────────────────────────────────┘
```

### 2.3 Why the Method Works

1. **Decomposition**: Divides the complex problem into smaller parts
2. **Patterns**: Identifies recurring situations
3. **Algorithms**: Each situation has a predefined solution
4. **Efficiency**: Minimizes moves through pattern recognition

---

## 3. The Analogy: Cube × Software

### 3.1 Direct Correlation Table

| Rubik's Cube | Software Testing | Applied Principle |
|--------------|------------------|-------------------|
| 43 quintillion positions | Thousands/millions of input combinations | **Combinatorial complexity** |
| 119 algorithms solve EVERYTHING | Minimum set of test cases covers EVERYTHING | **Strategic reduction** |
| Cross → F2L → OLL → PLL | Partitioning → Equivalence → Pairwise → BVA | **Step-by-step decomposition** |
| Recurring patterns identified | Equivalence classes grouped | **Pattern recognition** |
| Finger tricks for speed | Test automation | **Efficient execution** |
| Inspection before execution | Requirements analysis before testing | **Pre-planning** |

### 3.2 The Reduction Paradigm

```
RUBIK'S CUBE                     SOFTWARE TESTING
─────────────────                ─────────────────────

43,252,003,274,489,856,000       10 parameters × 5 values each
        positions                          = 9,765,625 combinations
              │                                  │
              ▼                                  ▼
    ┌─────────────────┐                ┌─────────────────┐
    │   119 algorithms │                │   ~50-100 tests │
    │   solve EVERYTHING│                │   cover 95%+    │
    └─────────────────┘                └─────────────────┘
              │                                  │
              ▼                                  ▼
    Reduction: 10^20               Reduction: 10^5
    to: 10^2                       to: 10^2
    
    FACTOR: 10^18                  FACTOR: 10^3
```

---

## 4. Test Case Reduction Techniques

### 4.1 Equivalence Class Partitioning (The "Cross")

#### Concept
Inputs that produce the same behavior are grouped into a single class. One test represents the entire class.

#### Partitioning Rules

| Partition Type | Description | Example |
|---------------|-------------|---------|
| **Valid** | Inputs the system should accept | Age: 18-65 years |
| **Invalid** | Inputs the system should reject | Age: < 18 or > 65 |
| **Boundary** | Values at partition limits | Age: 18, 65 |

#### Practical Example: "Age" Field

```
Scenario: Registration system accepts ages from 0 to 120 years

❌ NAIVE APPROACH (Test everything):
   Test 0, 1, 2, 3, 4... 119, 120 = 121 tests

✅ FRIEDRICH APPROACH (Partitioning):
   
   ┌─────────────────────────────────────────────┐
   │  Class 1: Invalid lower       │  Test: -1   │
   │  Class 2: Valid               │  Test: 25   │
   │  Class 3: Invalid upper       │  Test: 121  │
   │  Class 4: Non-numeric         │  Test: "abc"│
   └─────────────────────────────────────────────┘
   
   Reduction: 121 → 4 tests (96.7% savings!)
```

#### Partitioning Template

```markdown
### Test Case: [Field Name]

| Class | Type | Range/Condition | Test Value | Expected Result |
|-------|------|-----------------|------------|-----------------|
| EC-01 | Valid | [description] | [value] | [expected] |
| EC-02 | Invalid | [description] | [value] | [expected] |
| EC-03 | Boundary | [description] | [value] | [expected] |
```

---

### 4.2 Boundary Value Analysis (BVA) - The "F2L"

#### Concept
Errors tend to occur at interval limits, not in the middle. Testing limits is more efficient.

#### BVA Rules

For each interval [min, max], test:
1. **min - 1** (just below the limit)
2. **min** (at lower limit)
3. **min + 1** (just above lower limit)
4. **typical value** (in the middle of interval)
5. **max - 1** (just below upper limit)
6. **max** (at upper limit)
7. **max + 1** (just above the limit)

#### Practical Example: Item Quantity

```
Requirement: System accepts 1 to 100 items in cart

❌ NAIVE APPROACH:
   Test 1, 2, 3... 99, 100 = 100+ tests

✅ FRIEDRICH APPROACH (BVA):

   ┌─────────────────────────────────────────────┐
   │  Test 1: 0 items         → Reject (invalid) │
   │  Test 2: 1 item          → Accept (limit ↓) │
   │  Test 3: 2 items         → Accept (limit ↓+1)│
   │  Test 4: 50 items        → Accept (middle)  │
   │  Test 5: 99 items        → Accept (limit ↑-1)│
   │  Test 6: 100 items       → Accept (limit ↑) │
   │  Test 7: 101 items       → Reject (invalid) │
   └─────────────────────────────────────────────┘
   
   Reduction: 100+ → 7 tests (93% savings!)
```

#### BVA Decision Table

| Condition | Lower Limit | Middle | Upper Limit |
|-----------|-------------|--------|-------------|
| Valid - 1 | 0 | 49 | 99 |
| Valid (limit) | 1 | 50 | 100 |
| Valid + 1 | 2 | 51 | 101 |

---

### 4.3 Pairwise Testing - The "OLL"

#### Concept
Instead of testing all combinations, test ALL possible pairs of values. Based on the principle that most bugs are caused by the interaction of 2 parameters.

#### Why It Works

> **Pairwise Principle**: If a bug requires 3 or more specific conditions to occur, it will likely be found by testing all pairs.

#### Practical Example: System Configuration

```
Parameters and Values:
┌─────────────┬─────────────────────────────────┐
│ Parameter   │ Possible Values                 │
├─────────────┼─────────────────────────────────┤
│ Browser     │ Chrome, Firefox, Safari, Edge   │
│ OS          │ Windows, MacOS, Linux           │
│ Language    │ Portuguese, English, Spanish    │
│ Resolution  │ 1920x1080, 1366x768, 3840x2160  │
└─────────────┴─────────────────────────────────┘

❌ COMPLETE TEST (Cartesian Product):
   4 × 3 × 3 × 3 = 108 combinations!

✅ PAIRWISE (All pairs covered):
   Only 9-12 tests cover 100% of pairs!
```

#### Generated Pairwise Matrix

| Test | Browser | OS | Language | Resolution |
|------|---------|-----|----------|------------|
| T01 | Chrome | Windows | Portuguese | 1920x1080 |
| T02 | Chrome | MacOS | English | 1366x768 |
| T03 | Chrome | Linux | Spanish | 3840x2160 |
| T04 | Firefox | Windows | English | 3840x2160 |
| T05 | Firefox | MacOS | Spanish | 1920x1080 |
| T06 | Firefox | Linux | Portuguese | 1366x768 |
| T07 | Safari | Windows | Spanish | 1366x768 |
| T08 | Safari | MacOS | Portuguese | 3840x2160 |
| T09 | Safari | Linux | English | 1920x1080 |
| T10 | Edge | Windows | Portuguese | 1920x1080 |
| T11 | Edge | MacOS | English | 1366x768 |
| T12 | Edge | Linux | Spanish | 3840x2160 |

**Reduction: 108 → 12 tests (89% savings!)**

---

### 4.4 Decision Table - The "PLL"

#### Concept
Map all combinations of conditions that affect a business rule, eliminating impossible or redundant combinations.

#### Table Structure

```
┌─────────────┬─────────┬─────────┬─────────┬─────────┐
│ CONDITIONS  │  R1     │  R2     │  R3     │  R4     │
├─────────────┼─────────┼─────────┼─────────┼─────────┤
│ Condition A │   T/F   │   T/F   │   T/F   │   T/F   │
│ Condition B │   T/F   │   T/F   │   T/F   │   T/F   │
│ Condition C │   T/F   │   T/F   │   T/F   │   T/F   │
├─────────────┼─────────┼─────────┼─────────┼─────────┤
│ ACTION      │  [X]    │  [X]    │  [X]    │  [X]    │
└─────────────┴─────────┴─────────┴─────────┴─────────┘
```

#### Practical Example: Loan Approval

```
Conditions:
- C1: Income > $5,000
- C2: Credit Score > 700
- C3: Debt < 30% of income

❌ TOTAL COMBINATIONS: 2^3 = 8

✅ OPTIMIZED DECISION TABLE:

┌─────────────┬─────────┬─────────┬─────────┬─────────┐
│ CONDITION   │  R1     │  R2     │  R3     │  R4     │
├─────────────┼─────────┼─────────┼─────────┼─────────┤
│ Income>5k   │   Yes   │   Yes   │   No    │   No    │
│ Score>700   │   Yes   │   No    │   Yes   │   No    │
│ Debt<30%    │   Yes   │   Yes   │   Yes   │   No    │
├─────────────┼─────────┼─────────┼─────────┼─────────┤
│ APPROVED?   │   YES   │   YES   │   NO    │   NO    │
│ Priority    │  High   │  Medium │    -    │    -    │
└─────────────┴─────────┴─────────┴─────────┴─────────┘

Notes:
- R1: Ideal customer (high score, low debt, high income)
- R2: Good customer (high income compensates average score)
- R3: Insufficient income (rejected even with good score)
- R4: Low score + high debt (rejected)

Reduction: 8 → 4 significant rules (50% savings!)
```

---

## 5. Practical Application with Examples

### 5.1 Complete Scenario: E-commerce System

#### System Specification

```
System: Airline ticket sales platform

PARAMETERS:
┌──────────────┬────────────────────────────────────────┐
│ Parameter    │ Possible Values                        │
├──────────────┼────────────────────────────────────────┤
│ Origin       │ 10 cities (São Paulo, Rio, BH...)      │
│ Destination  │ 10 cities                              │
│ Class        │ Economy, Business, First               │
│ Payment      │ Credit, Boleto, Pix, Transfer          │
│ Baggage      │ Yes, No                                │
│ Date         │ Weekday, Weekend, Holiday              │
│ Passengers   │ 1, 2, 3, 4, 5+                         │
└──────────────┴────────────────────────────────────────┘

❌ COMPLETE TEST: 10 × 10 × 3 × 4 × 2 × 3 × 5 = 36,000 TESTS!
```

#### Applying "Friedrich" Techniques

##### Step 1: Partitioning (The "Cross")

```
City Reduction:
- National: São Paulo (represents all capitals)
- International: Miami (represents all international destinations)
- Regional: Campinas (represents inland cities)

10 cities → 3 categories (70% reduction)
```

##### Step 2: BVA (The "F2L")

```
Passengers:
- Lower limit: 1 passenger
- Upper limit: 5+ passengers
- Typical value: 2 passengers

5 values → 3 tests (40% reduction)
```

##### Step 3: Pairwise (The "OLL")

```
Parameters after partitioning:
- Origin: 3 (National, International, Regional)
- Destination: 3 (National, International, Regional)
- Class: 3
- Payment: 4
- Baggage: 2
- Date: 3
- Passengers: 3 (BVA applied)

Pairwise calculation: ~15-20 tests cover all pairs!
```

##### Final Result

| Approach | Number of Tests | Coverage |
|----------|-----------------|----------|
| Complete Test | 36,000 | 100% |
| Friedrich Approach | ~20 | ~95% of critical scenarios |
| **Savings** | **99.94%** | **Highly efficient** |

---

### 5.2 Scenario: Payment Processing API

#### Specification

```
Endpoint: POST /api/v1/payments

Parameters:
{
  "amount": decimal (0.01 - 10000.00),
  "currency": "BRL", "USD", "EUR",
  "method": "credit", "debit", "pix",
  "installments": 1-12,
  "card_token": string (required for credit/debit)
}
```

#### Optimized Test Table

| ID | Amount | Currency | Method | Installments | Card Token | Expected |
|----|--------|----------|--------|--------------|------------|----------|
| T01 | 0.01 | BRL | pix | 1 | null | Success (limit ↓) |
| T02 | 100.00 | USD | credit | 1 | valid | Success |
| T03 | 10000.00 | EUR | debit | 12 | valid | Success (limit ↑) |
| T04 | 0.00 | BRL | pix | 1 | null | Error (below) |
| T05 | 10000.01 | BRL | pix | 1 | null | Error (above) |
| T06 | 100.00 | BRL | credit | 1 | null | Error (token required) |
| T07 | 100.00 | BRL | credit | 13 | valid | Error (installments) |
| T08 | 100.00 | XXX | pix | 1 | null | Error (invalid currency) |

**Total: 8 tests cover 95%+ of scenarios!**

---

## 6. Tools and Implementation

### 6.1 Pairwise Testing Tools

| Tool | Type | Cost | Link |
|------|------|------|------|
| **PICT** | Desktop (Microsoft) | Free | Microsoft Download |
| **Pairwise Online** | Web | Free | pairwise.org |
| **ACTS** | Desktop (NIST) | Free | csrc.nist.gov |
| **Hexawise** | Web/SaaS | Paid | hexawise.com |
| **TConfig** | Java/Open Source | Free | SourceForge |
| **Jenny** | Command Line | Free | GitHub |

### 6.2 Example with PICT (Microsoft)

```
# Input file: parameters.txt
Browser: Chrome, Firefox, Safari, Edge
OS: Windows, MacOS, Linux
Language: Portuguese, English, Spanish
Resolution: 1920x1080, 1366x768, 3840x2160

# Command
pict parameters.txt /o:2 > testcases.txt

# Output: Pairwise matrix with all pairs covered
```

### 6.3 Example with Python (AllPair)

```python
# Installation: pip install allpairspy

from allpairspy import AllPairs

parameters = [
    ["Chrome", "Firefox", "Safari", "Edge"],
    ["Windows", "MacOS", "Linux"],
    ["PT", "EN", "ES"],
]

print("TEST | BROWSER | OS | LANGUAGE")
print("-" * 40)

for i, pairs in enumerate(AllPairs(parameters)):
    print(f"{i+1:5} | {pairs[0]:9} | {pairs[1]:7} | {pairs[2]}")
```

---

## 7. Templates and Checklists

### 7.1 "Friedrich" Test Plan Template

```markdown
# Test Plan: [System Name]

## 1. Requirements Analysis
- [ ] Identify all input parameters
- [ ] Document business rules
- [ ] Map dependencies between parameters

## 2. Partitioning
- [ ] Define equivalence classes for each parameter
- [ ] Identify valid and invalid partitions
- [ ] Document representative values

## 3. Boundary Values (BVA)
- [ ] Identify limits of each interval
- [ ] Define values: min-1, min, min+1, middle, max-1, max, max+1
- [ ] Create test cases for each limit

## 4. Pairwise
- [ ] List all parameters and their values
- [ ] Generate pairwise matrix with tool
- [ ] Validate coverage of all pairs

## 5. Decision Table
- [ ] Map complex business rules
- [ ] Create condition vs action table
- [ ] Eliminate impossible combinations

## 6. Execution
- [ ] Prioritize tests by risk
- [ ] Automate where possible
- [ ] Document results and defects
```

### 7.2 Test Quality Checklist

| Criterion | Question | Weight |
|-----------|----------|--------|
| **Coverage** | Are all requirements covered? | High |
| **Efficiency** | >= 80% reduction in number of tests? | High |
| **Boundaries** | Are all limits tested? | High |
| **Pairs** | Is pairwise applied where appropriate? | Medium |
| **Rules** | Do decision tables cover complex rules? | Medium |
| **Automation** | Are tests automatable? | Medium |
| **Maintenance** | Are tests easy to update? | Low |

### 7.3 Success Metrics

```
FRIEDRICH METHOD METRICS FOR TESTING

1. Reduction Rate (RR)
   RR = (Original Tests - Optimized Tests) / Original Tests × 100
   Target: RR >= 80%

2. Defect Efficiency (DE)
   DE = Defects Found / Tests Executed
   Compare with project baseline

3. Requirements Coverage (RC)
   RC = Tested Requirements / Total Requirements × 100
   Target: RC >= 95%

4. Execution Time (ET)
   ET = Optimized Execution Time / Original Time × 100
   Target: ET <= 20%
```

---

## 8. Conclusion

### 8.1 "Friedrich" Principles Applied

| Principle | Rubik's Cube | Software Testing |
|-----------|--------------|------------------|
| **Decomposition** | Cross → F2L → OLL → PLL | Equivalence → BVA → Pairwise → Decision |
| **Patterns** | 119 algorithms cover everything | Equivalence classes cover everything |
| **Efficiency** | ~60 moves solve 10^20 positions | ~50 tests cover 10^5 combinations |
| **Practice** | Requires memorization and training | Requires analysis and tools |

### 8.2 The "Friedrich" Tester Mindset

> **"Don't test EVERYTHING. Test what MATTERS strategically."**

1. **Identify patterns** → Equivalence classes
2. **Focus on limits** → BVA
3. **Cover interactions** → Pairwise
4. **Document rules** → Decision tables
5. **Measure results** → Efficiency metrics

### 8.3 Next Steps

1. Choose a functionality from your system
2. Apply equivalence class partitioning
3. Identify boundary values
4. Generate pairwise cases with a tool
5. Document in decision table
6. Measure the reduction achieved
7. Iterate and refine

---

## References

1. Myers, G. J. - "The Art of Software Testing" (3rd Edition)
2. Copeland, L. - "A Practitioner's Guide to Software Test Design"
3. Bach, J. & Bolton, M. - "Rapid Software Testing"
4. NIST - "Introduction to Combinatorial Testing" (SP 800-142)
5. Fridrich, J. - "The Fridrich Method for Speedcubing"

---

## Appendix A: Quick Conversion Table

| Situation | "Friedrich" Technique | Typical Savings |
|-----------|----------------------|-----------------|
| Numeric field with interval | BVA | 80-95% |
| Multiple independent parameters | Pairwise | 70-90% |
| Complex business rules | Decision Table | 50-70% |
| Fields with categories | Equivalence | 60-80% |
| Complete system | All combined | 85-99% |

---

*Document generated for study and practical application of test optimization techniques based on the Friedrich method.*

**Version**: 1.0  
**Date**: 2026-01-31  
**Author**: Friedrich Method × Software Testing Correlation Study
