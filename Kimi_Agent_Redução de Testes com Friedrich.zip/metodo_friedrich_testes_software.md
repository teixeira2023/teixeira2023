# Método Friedrich Aplicado à Otimização de Testes de Software

## Reduzindo Complexidade: Do Cubo de Rubik aos Casos de Teste

---

## Sumário

1. [Introdução](#1-introdução)
2. [O Método Friedrich (CFOP)](#2-o-método-friedrich-cfop)
3. [A Analogia: Cubo × Software](#3-a-analogia-cubo--software)
4. [Técnicas de Redução de Test Cases](#4-técnicas-de-redução-de-test-cases)
5. [Aplicação Prática com Exemplos](#5-aplicação-prática-com-exemplos)
6. [Ferramentas e Implementação](#6-ferramentas-e-implementação)
7. [Templates e Checklists](#7-templates-e-checklists)
8. [Conclusão](#8-conclusão)

---

## 1. Introdução

### 1.1 O Problema da Complexidade Combinatória

Em qualquer sistema de software não-trivial, o número de combinações possíveis de inputs, estados e cenários cresce exponencialmente. Testar todas as combinações é:

- **Financeiramente inviável**
- **Temporalmente impossível**
- **Praticamente desnecessário**

> **Princípio de Pareto nos Testes**: 80% dos bugs são encontrados com 20% dos testes bem escolhidos.

### 1.2 A Solução: Pensamento Estratégico

Assim como Jessica Fridrich desenvolveu um método para resolver o cubo de Rubik de forma eficiente, podemos aplicar os mesmos princípios para otimizar nossos testes de software.

---

## 2. O Método Friedrich (CFOP)

### 2.1 História e Contexto

| Aspecto | Detalhe |
|---------|---------|
| **Criadora** | Jessica Fridrich (Engenheira Checa) |
| **Ano** | Desenvolvido após o Campeonato Mundial de 1982 |
| **Tempo Médio** | ~17 segundos (speedcubers profissionais) |
| **Algoritmos Totais** | ~119 (41 F2L + 57 OLL + 21 PLL) |

### 2.2 As Quatro Etapas do CFOP

```
┌─────────────────────────────────────────────────────────────┐
│                    MÉTODO FRIEDRICH                         │
├─────────────────────────────────────────────────────────────┤
│  C → Cruz (Cross)          │  Montar cruz branca na base   │
│  F → F2L                   │  Primeiras duas camadas       │
│  O → OLL                   │  Orientar última camada       │
│  P → PLL                   │  Permutar última camada       │
└─────────────────────────────────────────────────────────────┘
```

### 2.3 Por que o Método Funciona?

1. **Decomposição**: Divide o problema complexo em partes menores
2. **Padrões**: Identifica situações recorrentes
3. **Algoritmos**: Cada situação tem uma solução predefinida
4. **Eficiência**: Minimiza movimentos através de reconhecimento de padrões

---

## 3. A Analogia: Cubo × Software

### 3.1 Tabela de Correlação Direta

| Cubo de Rubik | Testes de Software | Princípio Aplicado |
|---------------|-------------------|-------------------|
| 43 quintilhões de posições | Milhares/milhões de combinações de inputs | **Complexidade combinatória** |
| 119 algoritmos resolvem TUDO | Conjunto mínimo de test cases cobre TUDO | **Redução estratégica** |
| Cruz → F2L → OLL → PLL | Particionamento → Equivalência → Pairwise → BVA | **Decomposição em etapas** |
| Padrões recorrentes identificados | Classes de equivalência agrupadas | **Reconhecimento de padrões** |
| Finger tricks para velocidade | Automação de testes | **Execução eficiente** |
| Inspeção antes da execução | Análise de requisitos antes de testar | **Planejamento prévio** |

### 3.2 O Paradigma da Redução

```
CUBO DE RUBIK                    TESTES DE SOFTWARE
─────────────────                ─────────────────────

43.252.003.274.489.856.000       10 parâmetros × 5 valores cada
        posições                          = 9.765.625 combinações
              │                                  │
              ▼                                  ▼
    ┌─────────────────┐                ┌─────────────────┐
    │   119 algoritmos │                │   ~50-100 testes │
    │   resolvem TUDO  │                │   cobrem 95%+    │
    └─────────────────┘                └─────────────────┘
              │                                  │
              ▼                                  ▼
    Redução de: 10^20              Redução de: 10^5
    para: 10^2                     para: 10^2
    
    FATOR: 10^18                   FATOR: 10^3
```

---

## 4. Técnicas de Redução de Test Cases

### 4.1 Particionamento em Classes de Equivalência (A "Cruz")

#### Conceito
Inputs que produzem o mesmo comportamento são agrupados em uma única classe. Um teste representa toda a classe.

#### Regras de Particionamento

| Tipo de Partição | Descrição | Exemplo |
|-----------------|-----------|---------|
| **Válida** | Inputs que o sistema deve aceitar | Idade: 18-65 anos |
| **Inválida** | Inputs que o sistema deve rejeitar | Idade: < 18 ou > 65 |
| **Fronteira** | Valores no limite das partições | Idade: 18, 65 |

#### Exemplo Prático: Campo "Idade"

```
Cenário: Sistema de cadastro aceita idades de 0 a 120 anos

❌ ABORDAGEM INGENUA (Testar tudo):
   Testar 0, 1, 2, 3, 4... 119, 120 = 121 testes

✅ ABORDAGEM FRIEDRICH (Particionamento):
   
   ┌─────────────────────────────────────────────┐
   │  Classe 1: Inválida inferior    │  Teste: -1  │
   │  Classe 2: Válida               │  Teste: 25  │
   │  Classe 3: Inválida superior    │  Teste: 121 │
   │  Classe 4: Não-numérico         │  Teste: "abc"│
   └─────────────────────────────────────────────┘
   
   Redução: 121 → 4 testes (96,7% de economia!)
```

#### Template de Particionamento

```markdown
### Caso de Teste: [Nome do Campo]

| Classe | Tipo | Intervalo/Condição | Valor de Teste | Resultado Esperado |
|--------|------|-------------------|----------------|-------------------|
| CE-01 | Válida | [descrição] | [valor] | [esperado] |
| CE-02 | Inválida | [descrição] | [valor] | [esperado] |
| CE-03 | Fronteira | [descrição] | [valor] | [esperado] |
```

---

### 4.2 Análise de Valor Limite (BVA) - O "F2L"

#### Conceito
Erros tendem a ocorrer nos limites dos intervalos, não no meio. Testar os limites é mais eficiente.

#### Regras do BVA

Para cada intervalo [min, max], testar:
1. **min - 1** (logo abaixo do limite)
2. **min** (no limite inferior)
3. **min + 1** (logo acima do limite inferior)
4. **valor típico** (no meio do intervalo)
5. **max - 1** (logo abaixo do limite superior)
6. **max** (no limite superior)
7. **max + 1** (logo acima do limite)

#### Exemplo Prático: Quantidade de Itens

```
Requisito: Sistema aceita de 1 a 100 itens no carrinho

❌ ABORDAGEM INGENUA:
   Testar 1, 2, 3... 99, 100 = 100+ testes

✅ ABORDAGEM FRIEDRICH (BVA):

   ┌─────────────────────────────────────────────┐
   │  Teste 1: 0 itens        → Rejeitar (inválido)│
   │  Teste 2: 1 item         → Aceitar (limite ↓) │
   │  Teste 3: 2 itens        → Aceitar (limite ↓+1)│
   │  Teste 4: 50 itens       → Aceitar (meio)     │
   │  Teste 5: 99 itens       → Aceitar (limite ↑-1)│
   │  Teste 6: 100 itens      → Aceitar (limite ↑) │
   │  Teste 7: 101 itens      → Rejeitar (inválido)│
   └─────────────────────────────────────────────┘
   
   Redução: 100+ → 7 testes (93% de economia!)
```

#### Tabela de Decisão BVA

| Condição | Limite Inferior | Meio | Limite Superior |
|----------|----------------|------|-----------------|
| Válido - 1 | 0 | 49 | 99 |
| Válido (limite) | 1 | 50 | 100 |
| Válido + 1 | 2 | 51 | 101 |

---

### 4.3 Pairwise Testing (Teste de Pares) - A "OLL"

#### Conceito
Em vez de testar todas as combinações, testar TODOS os pares possíveis de valores. Baseado no princípio de que a maioria dos bugs é causada pela interação de 2 parâmetros.

#### Por que Funciona?

> **Princípio do Pairwise**: Se um bug requer 3 ou mais condições específicas para ocorrer, ele provavelmente será encontrado testando todos os pares.

#### Exemplo Prático: Configuração de Sistema

```
Parâmetros e Valores:
┌─────────────┬─────────────────────────────────┐
│ Parâmetro   │ Valores Possíveis               │
├─────────────┼─────────────────────────────────┤
│ Navegador   │ Chrome, Firefox, Safari, Edge   │
│ Sistema OS  │ Windows, MacOS, Linux           │
│ Idioma      │ Português, Inglês, Espanhol     │
│ Resolução   │ 1920x1080, 1366x768, 3840x2160  │
└─────────────┴─────────────────────────────────┘

❌ TESTE COMPLETO (Produto Cartesiano):
   4 × 3 × 3 × 3 = 108 combinações!

✅ PAIRWISE (Todos os pares cobertos):
   Apenas 9-12 testes cobrem 100% dos pares!
```

#### Matriz Pairwise Gerada

| Teste | Navegador | Sistema | Idioma | Resolução |
|-------|-----------|---------|--------|-----------|
| T01 | Chrome | Windows | Português | 1920x1080 |
| T02 | Chrome | MacOS | Inglês | 1366x768 |
| T03 | Chrome | Linux | Espanhol | 3840x2160 |
| T04 | Firefox | Windows | Inglês | 3840x2160 |
| T05 | Firefox | MacOS | Espanhol | 1920x1080 |
| T06 | Firefox | Linux | Português | 1366x768 |
| T07 | Safari | Windows | Espanhol | 1366x768 |
| T08 | Safari | MacOS | Português | 3840x2160 |
| T09 | Safari | Linux | Inglês | 1920x1080 |
| T10 | Edge | Windows | Português | 1920x1080 |
| T11 | Edge | MacOS | Inglês | 1366x768 |
| T12 | Edge | Linux | Espanhol | 3840x2160 |

**Redução: 108 → 12 testes (89% de economia!)**

---

### 4.4 Tabela de Decisão - A "PLL"

#### Conceito
Mapear todas as combinações de condições que afetam uma regra de negócio, eliminando combinações impossíveis ou redundantes.

#### Estrutura da Tabela

```
┌─────────────┬─────────┬─────────┬─────────┬─────────┐
│ CONDIÇÕES   │  R1     │  R2     │  R3     │  R4     │
├─────────────┼─────────┼─────────┼─────────┼─────────┤
│ Condição A  │   V/F   │   V/F   │   V/F   │   V/F   │
│ Condição B  │   V/F   │   V/F   │   V/F   │   V/F   │
│ Condição C  │   V/F   │   V/F   │   V/F   │   V/F   │
├─────────────┼─────────┼─────────┼─────────┼─────────┤
│ AÇÃO        │  [X]    │  [X]    │  [X]    │  [X]    │
└─────────────┴─────────┴─────────┴─────────┴─────────┘
```

#### Exemplo Prático: Aprovação de Empréstimo

```
Condições:
- C1: Renda > R$ 5.000
- C2: Score > 700
- C3: Dívida < 30% da renda

❌ COMBINAÇÕES TOTAIS: 2^3 = 8

✅ TABELA DE DECISÃO OTIMIZADA:

┌─────────────┬─────────┬─────────┬─────────┬─────────┐
│ CONDIÇÃO    │  R1     │  R2     │  R3     │  R4     │
├─────────────┼─────────┼─────────┼─────────┼─────────┤
│ Renda>5k    │   Sim   │   Sim   │   Não   │   Não   │
│ Score>700   │   Sim   │   Não   │   Sim   │   Não   │
│ Dívida<30%  │   Sim   │   Sim   │   Sim   │   Não   │
├─────────────┼─────────┼─────────┼─────────┼─────────┤
│ APROVADO?   │   SIM   │   SIM   │   NÃO   │   NÃO   │
│ Prioridade  │  Alta   │  Média  │    -    │    -    │
└─────────────┴─────────┴─────────┴─────────┴─────────┘

Notas:
- R1: Cliente ideal (alto score, baixa dívida, alta renda)
- R2: Cliente bom (alta renda compensa score médio)
- R3: Renda insuficiente (rejeitado mesmo com bom score)
- R4: Score baixo + dívida alta (rejeitado)

Redução: 8 → 4 regras significativas (50% de economia!)
```

---

## 5. Aplicação Prática com Exemplos

### 5.1 Cenário Completo: Sistema de E-commerce

#### Especificação do Sistema

```
Sistema: Plataforma de vendas de passagens aéreas

PARÂMETROS:
┌──────────────┬────────────────────────────────────────┐
│ Parâmetro    │ Valores Possíveis                      │
├──────────────┼────────────────────────────────────────┤
│ Origem       │ 10 cidades (São Paulo, Rio, BH...)     │
│ Destino      │ 10 cidades                             │
│ Classe       │ Econômica, Executiva, Primeira         │
│ Pagamento    │ Cartão, Boleto, Pix, Transferência     │
│ Bagagem      │ Sim, Não                               │
│ Data         │ Dia útil, Fim de semana, Feriado       │
│ Passageiros  │ 1, 2, 3, 4, 5+                         │
└──────────────┴────────────────────────────────────────┘

❌ TESTE COMPLETO: 10 × 10 × 3 × 4 × 2 × 3 × 5 = 36.000 TESTES!
```

#### Aplicação das Técnicas "Friedrich"

##### Etapa 1: Particionamento (A "Cruz")

```
Redução de Cidades:
- Nacional: São Paulo (representa todas as capitais)
- Internacional: Miami (representa todos os destinos internacionais)
- Interior: Campinas (representa cidades do interior)

10 cidades → 3 categorias (70% redução)
```

##### Etapa 2: BVA (O "F2L")

```
Passageiros:
- Limite inferior: 1 passageiro
- Limite superior: 5+ passageiros
- Valor típico: 2 passageiros

5 valores → 3 testes (40% redução)
```

##### Etapa 3: Pairwise (A "OLL")

```
Parâmetros após particionamento:
- Origem: 3 (Nacional, Internacional, Interior)
- Destino: 3 (Nacional, Internacional, Interior)
- Classe: 3
- Pagamento: 4
- Bagagem: 2
- Data: 3
- Passageiros: 3 (BVA aplicado)

Cálculo Pairwise: ~15-20 testes cobrem todos os pares!
```

##### Resultado Final

| Abordagem | Número de Testes | Cobertura |
|-----------|-----------------|-----------|
| Teste Completo | 36.000 | 100% |
| Abordagem Friedrich | ~20 | ~95% dos cenários críticos |
| **Economia** | **99,94%** | **Altamente eficiente** |

---

### 5.2 Cenário: API de Processamento de Pagamentos

#### Especificação

```
Endpoint: POST /api/v1/payments

Parâmetros:
{
  "amount": decimal (0.01 - 10000.00),
  "currency": "BRL", "USD", "EUR",
  "method": "credit", "debit", "pix",
  "installments": 1-12,
  "card_token": string (obrigatório para credit/debit)
}
```

#### Tabela de Testes Otimizada

| ID | Amount | Currency | Method | Installments | Card Token | Esperado |
|----|--------|----------|--------|--------------|------------|----------|
| T01 | 0.01 | BRL | pix | 1 | null | Sucesso (limite ↓) |
| T02 | 100.00 | USD | credit | 1 | valid | Sucesso |
| T03 | 10000.00 | EUR | debit | 12 | valid | Sucesso (limite ↑) |
| T04 | 0.00 | BRL | pix | 1 | null | Erro (abaixo) |
| T05 | 10000.01 | BRL | pix | 1 | null | Erro (acima) |
| T06 | 100.00 | BRL | credit | 1 | null | Erro (token obrigatório) |
| T07 | 100.00 | BRL | credit | 13 | valid | Erro (parcelas) |
| T08 | 100.00 | XXX | pix | 1 | null | Erro (moeda inválida) |

**Total: 8 testes cobrem 95%+ dos cenários!**

---

## 6. Ferramentas e Implementação

### 6.1 Ferramentas de Pairwise Testing

| Ferramenta | Tipo | Custo | Link |
|------------|------|-------|------|
| **PICT** | Desktop (Microsoft) | Gratuito | Microsoft Download |
| **Pairwise Online** | Web | Gratuito | pairwise.org |
| **ACTS** | Desktop (NIST) | Gratuito | csrc.nist.gov |
| **Hexawise** | Web/SaaS | Pago | hexawise.com |
| **TConfig** | Java/Open Source | Gratuito | SourceForge |
| **Jenny** | Command Line | Gratuito | GitHub |

### 6.2 Exemplo com PICT (Microsoft)

```
# Arquivo de entrada: parametros.txt
Navegador: Chrome, Firefox, Safari, Edge
Sistema: Windows, MacOS, Linux
Idioma: Portugues, Ingles, Espanhol
Resolucao: 1920x1080, 1366x768, 3840x2160

# Comando
pict parametros.txt /o:2 > testcases.txt

# Saída: Matriz pairwise com todos os pares cobertos
```

### 6.3 Exemplo com Python (AllPair)

```python
# Instalação: pip install allpairspy

from allpairspy import AllPairs

parametros = [
    ["Chrome", "Firefox", "Safari", "Edge"],
    ["Windows", "MacOS", "Linux"],
    ["PT", "EN", "ES"],
]

print("TESTE | NAVEGADOR | SISTEMA | IDIOMA")
print("-" * 40)

for i, pairs in enumerate(AllPairs(parametros)):
    print(f"{i+1:5} | {pairs[0]:9} | {pairs[1]:7} | {pairs[2]}")
```

---

## 7. Templates e Checklists

### 7.1 Template de Plano de Testes "Friedrich"

```markdown
# Plano de Testes: [Nome do Sistema]

## 1. Análise de Requisitos
- [ ] Identificar todos os parâmetros de entrada
- [ ] Documentar regras de negócio
- [ ] Mapear dependências entre parâmetros

## 2. Particionamento
- [ ] Definir classes de equivalência para cada parâmetro
- [ ] Identificar partições válidas e inválidas
- [ ] Documentar valores representativos

## 3. Valores Limite (BVA)
- [ ] Identificar limites de cada intervalo
- [ ] Definir valores: min-1, min, min+1, meio, max-1, max, max+1
- [ ] Criar casos de teste para cada limite

## 4. Pairwise
- [ ] Listar todos os parâmetros e seus valores
- [ ] Gerar matriz pairwise com ferramenta
- [ ] Validar cobertura de todos os pares

## 5. Tabela de Decisão
- [ ] Mapear regras de negócio complexas
- [ ] Criar tabela de condições vs ações
- [ ] Eliminar combinações impossíveis

## 6. Execução
- [ ] Priorizar testes por risco
- [ ] Automatizar onde possível
- [ ] Documentar resultados e defeitos
```

### 7.2 Checklist de Qualidade dos Testes

| Critério | Pergunta | Peso |
|----------|----------|------|
| **Cobertura** | Todos os requisitos estão cobertos? | Alta |
| **Eficiência** | Redução de >= 80% no número de testes? | Alta |
| **Fronteiras** | Todos os limites estão testados? | Alta |
| **Pares** | Pairwise foi aplicado onde apropriado? | Média |
| **Regras** | Tabelas de decisão cobrem regras complexas? | Média |
| **Automação** | Testes são automatizáveis? | Média |
| **Manutenção** | Testes são fáceis de atualizar? | Baixa |

### 7.3 Métricas de Sucesso

```
MÉTRICAS DO MÉTODO FRIEDRICH PARA TESTES

1. Taxa de Redução (TR)
   TR = (Testes Originais - Testes Otimizados) / Testes Originais × 100
   Meta: TR >= 80%

2. Eficiência de Defeitos (ED)
   ED = Defeitos Encontrados / Testes Executados
   Comparar com baseline do projeto

3. Cobertura de Requisitos (CR)
   CR = Requisitos Testados / Requisitos Totais × 100
   Meta: CR >= 95%

4. Tempo de Execução (TE)
   TE = Tempo de Execução Otimizado / Tempo Original × 100
   Meta: TE <= 20%
```

---

## 8. Conclusão

### 8.1 Os Princípios "Friedrich" Aplicados

| Princípio | Cubo de Rubik | Testes de Software |
|-----------|---------------|-------------------|
| **Decomposição** | Cruz → F2L → OLL → PLL | Equivalência → BVA → Pairwise → Decisão |
| **Padrões** | 119 algoritmos cobrem tudo | Classes de equivalência cobrem tudo |
| **Eficiência** | ~60 movimentos resolvem 10^20 posições | ~50 testes cobrem 10^5 combinações |
| **Prática** | Requer memorização e treino | Requer análise e ferramentas |

### 8.2 Mentalidade do Testador "Friedrich"

> **"Não teste TUDO. Teste o que IMPORTA de forma ESTRATÉGICA."**

1. **Identifique padrões** → Classes de equivalência
2. **Foque nos limites** → BVA
3. **Cubra interações** → Pairwise
4. **Documente regras** → Tabelas de decisão
5. **Meça resultados** → Métricas de eficiência

### 8.3 Próximos Passos

1. Escolha uma funcionalidade do seu sistema
2. Aplique o particionamento em classes de equivalência
3. Identifique valores limite
4. Gere casos pairwise com ferramenta
5. Documente em tabela de decisão
6. Meça a redução obtida
7. Itere e refine

---

## Referências

1. Myers, G. J. - "The Art of Software Testing" (3rd Edition)
2. Copeland, L. - "A Practitioner's Guide to Software Test Design"
3. Bach, J. & Bolton, M. - "Rapid Software Testing"
4. NIST - "Introduction to Combinatorial Testing" (SP 800-142)
5. Fridrich, J. - "The Fridrich Method for Speedcubing"

---

## Apêndice A: Tabela de Conversão Rápida

| Situação | Técnica "Friedrich" | Economia Típica |
|----------|---------------------|-----------------|
| Campo numérico com intervalo | BVA | 80-95% |
| Múltiplos parâmetros independentes | Pairwise | 70-90% |
| Regras de negócio complexas | Tabela de Decisão | 50-70% |
| Campos com categorias | Equivalência | 60-80% |
| Sistema completo | Todas combinadas | 85-99% |

---

*Documento gerado para estudo e aplicação prática de técnicas de otimização de testes baseadas no método Friedrich.*

**Versão**: 1.0  
**Data**: 2026-01-31  
**Autor**: Estudo de Correlação Método Friedrich × Testes de Software
